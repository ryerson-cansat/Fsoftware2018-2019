Simple release program for testing structures.

Need a switch connected to pin 7 on trigger for activating high and low signals.

Detonation needs a mosfet to be activated by pin 7 to burn a resistor.
